import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine3;

/**
 * Generate Tag Cloud Generator. The output file should be based on HTML format
 * and follow the tagcloud.css format. The number of words in the output is
 * determined by user and should be in alphabetically order. All the words
 * should be lower cases. Only use the component package from OSU.
 *
 *
 * @author Jihyung Kil
 *
 * @version 12/01/2015
 *
 *
 */
public class TagCloudGenerator {

    private static int minValue = 0;

    private static int maxValue = 0;

    private static class IntegerLT
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> o1,
                Map.Pair<String, Integer> o2) {
            int v1 = o1.value();
            int v2 = o2.value();

            if (v1 < v2) {
                return 1;
            } else if (v1 > v2) {
                return -1;
            } else {
                return 0;
            }
        }
    }

    private static class StringLT
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        public int compare(Map.Pair<String, Integer> o1,
                Map.Pair<String, Integer> o2) {

            String s1 = o1.key();
            String s2 = o2.key();
            if (s1.compareTo(s2) < 0) {
                return -1;
            } else if (s1.compareTo(s2) > 0) {
                return 1;
            } else {
                return 0;
            }
        }
    }

    /*
     * Count the words which appear in the input file. In order to count, we
     * first need to set up the set of seperators. Call a generateElements
     * method to make seperatorSet. Finally, call mapOFWordAndCount to make a
     * map which contains words and counts.
     *
     * @param table a Map of words and each words' count
     *
     * @param inFile a input file which consists of words, sentences and
     * paragraphs .
     *
     *
     * @requires |table| = 0, the string of seperatorStr should have valid
     * seperators.
     *
     * @ensures
     *
     * each pair of table has different keys and the exact number of keys
     * occurrences. all seperators in str should be included in seperatorSet.
     */
    public static void countWord(Map<String, Integer> table,
            SimpleReader inFile) {

        final String seperatorStr = " ,:-.[]'`\"*()";
        Set<Character> seperatorSet = new Set1L<>();
        generateElements(seperatorStr, seperatorSet);
        mapOfWordsAndCount(seperatorSet, table, inFile);
    }

    /*
     * define String str and assign its "charAt(position)" to Set<Character>
     * seperatorSet.
     *
     * @param str a string of seperators
     *
     * @param seperatorSet a Set<Chracter> in which each seperator in str will
     * be added.
     *
     * @requires |str| > 0 and |seperatorSet| = 0
     *
     * @ensures all seperators in str should be included in seperatorSet. |str|
     * = |seperatorSet|
     */
    public static void generateElements(String str,
            Set<Character> seperatorSet) {
        int i = 0;
        char ch = '1';
        while (i < str.length()) {
            ch = str.charAt(i);
            if (!seperatorSet.contains(ch)) {
                seperatorSet.add(ch);
            }
            i++;
        }
    }

    /*
     * make a map which consists of word and its count.
     *
     * @param separatorSet a Set<Character> of seperators
     *
     * @param table a map of words and counts
     *
     * @requires |sepratorSet| > 0
     *
     * @ensures <pre> each pair of table has different keys and the exact number
     * of keys occurrences. beginIndex = 1st position of each word endIndex =
     * last position of each word keep increasing endIndex until it encounters
     * seperators. after that, assign eachSentence.substring(beginIndex,
     * endIndex) to String eachWord. put the word into Map <key> and count it as
     * 1. Repeat this until end of one sentence. if same word appears, add 1 to
     * Map <value>. If new word appears, add it in the new Map pair<key, value>.
     * keep doing this until there is no sentence left. </pre>
     */
    public static void mapOfWordsAndCount(Set<Character> seperatorSet,
            Map<String, Integer> table, SimpleReader inFile) {

        String eachSentence = "";
        String eachWord = "";
        while (!inFile.atEOS()) {
            eachSentence = inFile.nextLine().toLowerCase();
            int beginIndex = 0;
            int endIndex = 0;
            while (beginIndex < eachSentence.length()) {

                while (endIndex < eachSentence.length() && !seperatorSet
                        .contains(eachSentence.charAt(endIndex))) {
                    endIndex++;
                }

                eachWord = eachSentence.substring(beginIndex, endIndex);
                if (eachWord.length() != 0) {
                    if (table.hasKey(eachWord)) {
                        int count = table.value(eachWord);
                        table.replaceValue(eachWord, count + 1);
                    } else {
                        table.add(eachWord, 1);
                    }

                }

                beginIndex = endIndex + 1;
                endIndex++;
            }
        }

    }

    /*
     * Sort a SortingMachine<Pair<String, Integer>> in decreasing order with
     * size numOfWords.
     *
     * @param decreasingOrder a SortingMachine<Pair<String, Integer>>> which
     * contains words with size numOfWords in decreasing order.
     *
     * @param table a Map<String, Integer> containing all the words from
     * inputFile.
     *
     * @param numOfWords the number of words to be included in the generated tag
     * cloud.
     *
     * @requires |decreasingOrder| = 0
     *
     * @ensures
     *
     * |decreasingOrder| = numOfWords. decreasingOrder should be in decreasing
     * order. maxValue = first value of decreasingOrder. minValue = last value
     * of decreasingOrder.
     */
    public static void decreasingOrderOfCountsN(
            SortingMachine<Pair<String, Integer>> decreasingOrder,
            Map<String, Integer> table, int numOfWords) {

        while (table.size() > 0) {
            Map.Pair<String, Integer> eachPair = table.removeAny();
            decreasingOrder.add(eachPair);

        }

        decreasingOrder.changeToExtractionMode();

        SortingMachine<Pair<String, Integer>> decreasingOrderOfN = decreasingOrder
                .newInstance();

        Map.Pair<String, Integer> maxPair = decreasingOrder.removeFirst();
        decreasingOrderOfN.add(maxPair);
        maxValue = maxPair.value();

        int i = 1;
        while (i < numOfWords) {
            Map.Pair<String, Integer> pair = decreasingOrder.removeFirst();
            decreasingOrderOfN.add(pair);
            if (i == (numOfWords - 1)) {
                minValue = pair.value();
            }
            i++;
        }
        decreasingOrder.transferFrom(decreasingOrderOfN);

    }

    /*
     * Sort a SortingMachine<Pair<String, Integer>> in alphabetical order.
     *
     * @param alphabeticalOrder a SortingMachine<Pair<String, Integer>>> which
     * contains words in alphabetical order.
     *
     * @param decreasingOrder a Map<String, Integer> which contains words with
     * size numOfWords in decreasing order.
     *
     * @requires |alphabeticalOrder| = 0
     *
     * @ensures
     *
     * |alphabeticalOrder| = |#decreasingOrder| |decreasingOrder| = 0
     * perm(alphabeticalOrder) = decreasingOrder.
     */
    public static void alphabeticallyOrderOfWords(
            SortingMachine<Pair<String, Integer>> alphabeticalOrder,
            SortingMachine<Pair<String, Integer>> decreasingOrder) {

        decreasingOrder.changeToExtractionMode();
        while (decreasingOrder.size() != 0) {
            Map.Pair<String, Integer> pair = decreasingOrder.removeFirst();
            alphabeticalOrder.add(pair);

        }

    }

    /*
     * create HtmlFile.
     *
     * @param outFile a output file based on HTML format.
     *
     * @param alphabeticalOrder a SortingMachine<Pair<String, Integer>> with
     * size N and alphabeticalOrder.
     *
     * @param inputFileName a input file which consists of words, sentences and
     * paragraphs
     *
     * @requires outFile's format = .html, inputFileName must exist.
     *
     * @ensures
     *
     * The html output should follow the tagcloud.css format. Each word should
     * be converted to lower case. The number of words in the output =
     * alphabeticalOrder.size()
     */
    public static void makeHtmlFile(SimpleWriter outFile,
            SortingMachine<Pair<String, Integer>> alphabeticalOrder,
            String inputFileName) {
        outFile.println("<!DOCTYPE html>");
        outFile.println("<html>");

        outFile.println("<head>");
        outFile.println("<title>");
        outFile.print("Top" + alphabeticalOrder.size() + "  Words in  "
                + inputFileName);
        outFile.println("</title>");

        outFile.println(
                "<link rel=\"stylesheet\" type=\"text/css\" href=\"tagcloud.css\">");
        outFile.println("</head>");

        outFile.println("<body>");

        outFile.print("<h style=\"font-size:200%\">Top "
                + alphabeticalOrder.size() + " words in " + inputFileName);
        outFile.println("</h>");
        outFile.print("<hr noshade size=2 width =\"100%\">");
        outFile.println("</hr>");

        outFile.println("<p class=\"cbox\">");
        alphabeticalOrder.changeToExtractionMode();
        while (alphabeticalOrder.size() != 0) {

            Map.Pair<String, Integer> pair = alphabeticalOrder.removeFirst();
            int fontSize = determineFontSize(maxValue, minValue, pair.value());
            outFile.print("<span class=\"f" + fontSize
                    + "\" style=\"cursor:default\">" + pair.key() + " "
                    + "</span>");

        }

        outFile.println("</p>");

        outFile.println("</body>");
        outFile.println("</html>");
        outFile.close();
    }

    /*
     * determine font size of each word. The font size of each word shall be
     * proportional to the number of occurrences of the word in the input text.
     *
     * @param maxValue maximum value
     *
     * @param minValue minimum value
     *
     * @param currentValue
     *
     * @requires minValue <=currentValue && currentValue <= maxValue
     *
     * @ensures minFontSize <= fontSize && fontSize <= maxFontSize #minFontSize
     * = miniFontSize, #maxFontSize= maxFontSize.
     */
    public static int determineFontSize(int maxValue, int minValue,
            int currentValue) {
        int fontSize = 0;
        int maxFontSize = 48;
        int minFontSize = 11;
        int range = (maxValue - minValue);
        int term = range / (maxFontSize - minFontSize);
        fontSize = (currentValue / term) + minFontSize;
        return fontSize;
    }

    /**
     * Ask a user names of inputFile and outFile. Also ask a user the number of
     * words to be included in the generated tag cloud. Call a countWord method
     * and a decreasingOrderOfCountsN method. call alphabeticallyOrderOfWords
     * method. Finally, call makeHtmlFile method to make a htmlFile.
     *
     * @param args
     * @requires the input file must be stored in data directory.
     * @ensures the output file must be HTML format.
     *
     */

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the input file: ");
        String inputFileName = in.nextLine();
        while (!inputFileName.endsWith(".txt")) {
            out.println(
                    "Invalid file type. Please enter an existing text file. File must be in project directory. ");
            inputFileName = in.nextLine();
        }
        SimpleReader inFile = new SimpleReader1L(inputFileName);

        Map<String, Integer> table = new Map1L<>();
        countWord(table, inFile);

        out.print("Enter the name of output file: ");
        String htmlFile = in.nextLine();
        while (!htmlFile.endsWith(".html")) {
            out.println("Invalid file type. Please enter a html output file: ");
            htmlFile = in.nextLine();
        }
        SimpleWriter outFile = new SimpleWriter1L(htmlFile);

        out.print(
                "Enter the number of words to be included in the generated tag cloud: ");
        int numOfWords = in.nextInteger();

        Comparator<Pair<String, Integer>> ci = new IntegerLT();
        SortingMachine<Pair<String, Integer>> decreasingOrder = new SortingMachine3<>(
                ci);
        decreasingOrderOfCountsN(decreasingOrder, table, numOfWords);

        Comparator<Pair<String, Integer>> qi = new StringLT();
        SortingMachine<Pair<String, Integer>> alphabeticalOrder = new SortingMachine3<>(
                qi);

        alphabeticallyOrderOfWords(alphabeticalOrder, decreasingOrder);

        makeHtmlFile(outFile, alphabeticalOrder, inputFileName);

        in.close();
        out.close();

    }
}
